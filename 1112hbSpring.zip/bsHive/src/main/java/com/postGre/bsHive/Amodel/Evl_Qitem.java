package com.postGre.bsHive.Amodel;

import lombok.Data;

@Data
public class Evl_Qitem {
	private int evl_detnum; 	//문항번호
	private String evl_detail;	//문항내용
}
