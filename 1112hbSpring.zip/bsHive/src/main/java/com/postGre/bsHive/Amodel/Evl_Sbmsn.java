package com.postGre.bsHive.Amodel;

import lombok.Data;

@Data
public class Evl_Sbmsn {
	private int 	evl_ox; 	//강의평가유무
	private int		evl_detnum;	//문항번호
	private int 		lctr_num;	// 강의번호
	private int		unq_num;  	// 고유학생번호
	private int		 evl_num; 	//선택숫자
	
}
